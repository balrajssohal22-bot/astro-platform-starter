# Chisn Jio Mart — Strategy Website (Student Project)

This static website bundles a complete coursework analysis using **JioMart** as the studied website:

- Task 1: E‑business model
- Task 2: Competitive & digital business strategy
- Task 3: Digital marketing
- Task 4: Traffic intelligence (Similarweb/Semrush)
- Task 5: e‑CRM & social
- Task 6: Cybersecurity & ethics

It also includes a **Digital Story** page you can adapt for video/Reels.

## How to run locally
Open `index.html` in your browser, or serve the folder:

```bash
python3 -m http.server 8080
```

Then visit http://localhost:8080

## How to deploy (free)
- **Netlify**: drag‑and‑drop this folder
- **Vercel**: `vercel` → select folder
- **GitHub Pages**: push to a repo, enable Pages → `main / root`

## Suggested domain
`chisn-jiomart-insights.site` (or any you prefer). Update references in the footer if you purchase a domain.

## Sources
All sources are linked inline on each task page. Metrics from Similarweb/Semrush are **estimates** and may vary.
